package com.mars.poc.person.info;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonSprigbootH2Application {

	public static void main(String[] args) {
		SpringApplication.run(PersonSprigbootH2Application.class, args);
	}
}
